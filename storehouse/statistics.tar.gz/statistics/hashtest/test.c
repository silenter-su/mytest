#include <stdio.h>
#include "sessionmap.h"

void main ()
{
	int i = 0;
	unsigned int j = 0;
	int ret = 0;


	SessionMap* sessionmap = NULL;

	sessionmap = ssm_new(100);
	printf("now hashmap size is : %d\n",ssm_get_count(sessionmap));

	IPSession sess_1;
	memset(&sess_1,0,sizeof(IPSession));
	ret = ssm_put(sessionmap,1,sess_1);
	printf("now hashmap size is : %d\n ret = %d \n",ssm_get_count(sessionmap),ret);

	ssm_delete(sessionmap);
	
	return;
}
